<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Treigh PM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# Quill
Version: 1.0.1 Beta
![Introducing Quill](http://cdn.kleverr.com/pjx/quill/img/demo/quill-screenshot-10.jpg)

Quill is a sleek, modern and _clutter-free_ blog theme for [MODX](http://modx.com) that offers a more immersive reading experience. In just a few clicks, you\'ll have a fully functioning blog—thanks to MODX package dependencies.

## Demo
Quill is best previewed on the following pages:
1. [Live demo blog](http://quill.kleverr.modxcloud.com)
2. [Pattern Library](http://quill.kleverr.modxcloud.com/pattern-library/)
3. [Flight Manual](http://quill.kleverr.modxcloud.com/flight-manual/)

## Who is it for?
Quill is a One-Stop blogging solution for MODX that\'s designed to quickly get you in writing mode. By taking care of the heavy lifting, it allows you to focus on what matters most to you: Publishing your thoughts.

## Requirements

**MODX 2.4+** (Quill [installs](http://quill.kleverr.modxcloud.com/flight-manual/) required extras via package dependencies)

## Installation

1. [Download](http://modx.com/extras/package/quill) Quill via Package Management.
2. Click Install and follow the instructions.
3. Clear Cache.
4. Turn on Friendly URLs.

## Getting Started

- Visit Quill\'s official [documentation](http://quill.kleverr.modxcloud.com/flight-manual) to get started.
- Check out Quill\'s [Pattern Library](http://c0028.paas2.tx.modxcloud.com/introducing-quill/) for a complete style guide

## Included Extras

Quill installs the following extras to get things running:

- Collections
- Tagger
- pdoTools
- Archivist
- SimpleSearch
- ClientConfig
- If
- getUrlParam
- Rowboat
- Gravatar

## Main Features
![Image of a sample blog post themed by Quill](http://cdn.kleverr.com/pjx/quill/img/demo/quill-shot-9.png)

- Easily Customizable within the manager
- Pattern library for style references
- Clean, intuitive well-structured and well-commented markup
- Fully commented Sass source files
- Syntax highlighting (Prism.js)
- Built with Bootstrap V4 (alpha)
- Suggested posts
- Widgets: Newsletter signup form, Social share links, side notes, etc.
- Optional featured images
- SEO-optimized
- Cross-Browser Compatibility: Chrome, FF, Safari, Edge, Opera, IE9+
- 100% Responsive
- And more!

## Credits

Quill wouldn\'t be possible without these very useful assets:

- [JQuery](http://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js)
- [Bootstrap](http://v4-alpha.getbootstrap.com/)
- [Unveil.js](http://luis-almeida.github.io/unveil/)
- [Prism.js](http://prismjs.com/)
- Reading Time by [Michael Lynch](http://michaelynch.com/)
- [Disqus](http://c0028.paas2.tx.modxcloud.com/disqus.com)
- [SVG Icons](http://c0028.paas2.tx.modxcloud.com/svgicons.sparkk.fr)

Special thanks to MODX\'s John Peca (@theboxer) and Wayne Roddy (@dubROD) for the for the groundwork. Flatso theme and Git Package Management were invaluable when developing Quill. Shout-out to @donshakespeare for intensively testing out Quill\'s initial Beta release.
',
    'changelog' => 'Changelog file for Quill extra.

# Quill 1.0.1-beta (January 21, 2016)
===================================

- Fix Download URL
- Switch to pdoResources for archives and fix missing archives
- Add custom Collections view template to assets
- Center hero header on all screen sizes
- Increase stack order of float bars
- Add tether.min.js for Bootstrap tooltips
- Add Smooth Scrolling in page scripts
- Fix broken search icon on Safari

# Quill 1.0.0-beta (January 17, 2016)
===================================

- Initial release
',
    'setup-options' => 'quill-1.0.1-beta/setup-options.php',
    'requires' => 
    array (
      'collections' => '>=3.2.0',
      'tagger' => '>=1.7.0',
      'pdotools' => '>=2.2.0',
      'archivist' => '>=1.2.0',
      'simplesearch' => '>=1.9.0',
      'if' => '>=1.1.0',
      'geturlparam' => '>=1.0',
      'clientconfig' => '>=1.3.0',
      'rowboat' => '>=1.1.0',
      'gravatar' => '>=2.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e9fc4ae1cc936e8c9264e6370e56ad52',
      'native_key' => 'quill',
      'filename' => 'modNamespace/093d8c30074f3610ffd8250926fdbaa6.vehicle',
      'namespace' => 'quill',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdce2528f2b5afef699c3c3e1840dca9',
      'native_key' => 'quill.doc_container',
      'filename' => 'modSystemSetting/8a77580b771c1d8c63615f1a4435e000.vehicle',
      'namespace' => 'quill',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '002e94f51ed5b18778fb46db98b4af52',
      'native_key' => 'quill.blog_container',
      'filename' => 'modSystemSetting/91f71c9aebded87c6c4a7e62425990e9.vehicle',
      'namespace' => 'quill',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '266c525379a4d0d873420f8ef44cebdd',
      'native_key' => 'quill.sections_page',
      'filename' => 'modSystemSetting/3ddb7fe5707b41779bfe24e73e1d3699.vehicle',
      'namespace' => 'quill',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56cb772295be2c62f1b80d75e39b36f0',
      'native_key' => 'quill.topics_page',
      'filename' => 'modSystemSetting/b51ea2bdb4c12145cd252d452fa25d64.vehicle',
      'namespace' => 'quill',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e9ec68f57c7ec6ef17c911030ee6c8e',
      'native_key' => 'quill.authors_page',
      'filename' => 'modSystemSetting/494b22b40a61da0366d842c30f3e6cb7.vehicle',
      'namespace' => 'quill',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c880d49638541524c7cfea97bdaa7c91',
      'native_key' => 'quill.archives_page',
      'filename' => 'modSystemSetting/a98846eb4e8b178ca3b154e4f7c67f9d.vehicle',
      'namespace' => 'quill',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a27909334f966035696ca40a540b8ef6',
      'native_key' => 'quill.default_author_page',
      'filename' => 'modSystemSetting/08dff5bc7500b9be9927f37f46b4cfe5.vehicle',
      'namespace' => 'quill',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c06907a231cf5c9d3f659bd81c3060a',
      'native_key' => 'quill.search_page',
      'filename' => 'modSystemSetting/dd80251885c9aa25817433321ee3f40d.vehicle',
      'namespace' => 'quill',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ea320a810bfa2bc285099b93ae90a11',
      'native_key' => 'quill.rss_page',
      'filename' => 'modSystemSetting/0acec821e370532b1385a7c8c2414ba3.vehicle',
      'namespace' => 'quill',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'db90df057824322d3777e1134827fe22',
      'native_key' => NULL,
      'filename' => 'modCategory/ec754d7ef803b41a967f6e091b7e6f67.vehicle',
      'namespace' => 'quill',
    ),
  ),
);