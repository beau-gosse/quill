<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Treigh PM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# Quill
Version: 1.0.3 Beta
![Introducing Quill](http://cdn.kleverr.com/pjx/quill/img/demo/quill-screenshot-10.jpg)

Quill is a sleek, modern and _clutter-free_ blog theme for [MODX](http://modx.com) that offers a more immersive reading experience. In just a few clicks, you\'ll have a fully functioning blog—thanks to MODX package dependencies.

## Demo
Quill is best previewed on the following pages:
1. [Live demo blog](http://quill.kleverr.modxcloud.com)
2. [Pattern Library](http://quill.kleverr.modxcloud.com/pattern-library/)
3. [Flight Manual](http://quill.kleverr.modxcloud.com/flight-manual/)

## Who is it for?
Quill is a One-Stop blogging solution for MODX that\'s designed to quickly get you in writing mode. By taking care of the heavy lifting, it allows you to focus on what matters most to you: Publishing your thoughts.

## Requirements

**MODX 2.4+** (Quill [installs](http://quill.kleverr.modxcloud.com/flight-manual/) required extras via package dependencies)

## Installation

1. [Download](http://modx.com/extras/package/quill) Quill via Package Management.
2. Click Install and follow the instructions.
3. Clear Cache.
4. Turn on Friendly URLs. (+ Rename the `ht.access` file to `.htaccess`)

## Getting Started

- Visit Quill\'s official [documentation](http://quill.kleverr.modxcloud.com/flight-manual) to get started.
- Check out Quill\'s [Pattern Library](http://c0028.paas2.tx.modxcloud.com/introducing-quill/) for a complete style guide

## Included Extras

Quill installs the following extras to get things running:

- Collections
- Tagger
- pdoTools
- Archivist
- SimpleSearch
- ClientConfig
- If
- getUrlParam
- Rowboat
- Gravatar

## Main Features
![Image of a sample blog post themed by Quill](http://cdn.kleverr.com/pjx/quill/img/demo/quill-shot-9.png)

- Easily Customizable within the manager
- Pattern library for style references
- Clean, intuitive well-structured and well-commented markup
- Fully commented Sass source files
- Syntax highlighting (Prism.js)
- Built with Bootstrap V4 (alpha)
- Suggested posts
- Widgets: Newsletter signup form, Social share links, side notes, etc.
- Optional featured images
- SEO-optimized
- Cross-Browser Compatibility: Chrome, FF, Safari, Edge, Opera, IE9+
- 100% Responsive
- And more!

## Credits

Quill wouldn\'t be possible without these very useful assets:

- [JQuery](http://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js)
- [Bootstrap](http://v4-alpha.getbootstrap.com/)
- [Unveil.js](http://luis-almeida.github.io/unveil/)
- [Prism.js](http://prismjs.com/)
- Reading Time by [Michael Lynch](http://michaelynch.com/)
- [Disqus](http://c0028.paas2.tx.modxcloud.com/disqus.com)
- [SVG Icons](http://c0028.paas2.tx.modxcloud.com/svgicons.sparkk.fr)

Special thanks to MODX\'s John Peca (@theboxer) and Wayne Roddy (@dubROD) for the groundwork. Flatso theme and Git Package Management were invaluable when developing Quill. Shout-out to @donshakespeare for intensively testing out Quill\'s initial Beta release.
',
    'changelog' => 'Changelog file for Quill extra.

# Quill 1.0.3-beta (February 3, 2016)
===================================

- Improve mobile responsiveness
- Fix typo in Thoughts pagetitle [#1]
- UI improvements

# Quill 1.0.2-beta (January 25, 2016)
===================================

- Align pagination + newsletter form with content
- Fix hero image center alignment
- Remove hero image caption
- Further style tweaks

# Quill 1.0.1-beta (January 21, 2016)
===================================

- Fix Download URL
- Switch to pdoResources for archives and fix missing archives
- Add custom Collections view template to assets
- Center hero header on all screen sizes
- Increase stack order of float bars
- Add tether.min.js for Bootstrap tooltips
- Add Smooth Scrolling in page scripts
- Fix broken search icon on Safari

# Quill 1.0.0-beta (January 17, 2016)
===================================

- Initial release
',
    'setup-options' => 'quill-1.0.3-beta/setup-options.php',
    'requires' => 
    array (
      'collections' => '>=3.2.0',
      'tagger' => '>=1.7.0',
      'pdotools' => '>=2.2.0',
      'archivist' => '>=1.2.0',
      'simplesearch' => '>=1.9.0',
      'if' => '>=1.1.0',
      'geturlparam' => '>=1.0',
      'clientconfig' => '>=1.3.0',
      'rowboat' => '>=1.1.0',
      'gravatar' => '>=2.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c038c4f6a61888dc6181d07f3e6e5a4f',
      'native_key' => 'quill',
      'filename' => 'modNamespace/d8461f53aaac880db349f44e9ea772e9.vehicle',
      'namespace' => 'quill',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9fe914393a5c1d7173d0ecb2e200d12',
      'native_key' => 'quill.doc_container',
      'filename' => 'modSystemSetting/7f1ea9e0a2b9489f76d2221f4f2bb78c.vehicle',
      'namespace' => 'quill',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5ec3ad686eea65add4577691b418312',
      'native_key' => 'quill.blog_container',
      'filename' => 'modSystemSetting/9c205db39f847bf4852751d9243eac2a.vehicle',
      'namespace' => 'quill',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bbd5be58483b99a2b881de22330ef16',
      'native_key' => 'quill.sections_page',
      'filename' => 'modSystemSetting/91ab54f7e3dbfbc310978663ada283fe.vehicle',
      'namespace' => 'quill',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7b497f7048a12dfb9dcd277427e1713',
      'native_key' => 'quill.topics_page',
      'filename' => 'modSystemSetting/106d7ba1ffdc1d9a4fb36475d45b8b14.vehicle',
      'namespace' => 'quill',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e91c5c93148fc65e193379690a300ed',
      'native_key' => 'quill.authors_page',
      'filename' => 'modSystemSetting/24df824a19d1598d97d204b768be9cd4.vehicle',
      'namespace' => 'quill',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd98b18436f3cd4911873beff7ebebaf',
      'native_key' => 'quill.archives_page',
      'filename' => 'modSystemSetting/bd636cdd3cecffc267695f32e535a7e3.vehicle',
      'namespace' => 'quill',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6005b0051b3a285a6b7d92a2da59349f',
      'native_key' => 'quill.default_author_page',
      'filename' => 'modSystemSetting/3e82ddd01f921adf2e62660d26851534.vehicle',
      'namespace' => 'quill',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2dc586d680dc0ac0cc452ac575cee71d',
      'native_key' => 'quill.search_page',
      'filename' => 'modSystemSetting/94adc05a1847222cd810c821f098283f.vehicle',
      'namespace' => 'quill',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c78dc62a9d5cf0dd28c1f2f9e6f78eaa',
      'native_key' => 'quill.rss_page',
      'filename' => 'modSystemSetting/8025e33f694901a51958dd39bdd1fbea.vehicle',
      'namespace' => 'quill',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2e7465c3cfd23938b483b828ad2463fc',
      'native_key' => NULL,
      'filename' => 'modCategory/3399ed72fd7a0eec2aab1f3f653c95bb.vehicle',
      'namespace' => 'quill',
    ),
  ),
);