Changelog file for Quill extra.

# Quill 1.0.0-beta (January 17, 2016)
===================================

- Initial release
