Changelog file for Quill extra.

# Quill 1.1.0-beta (February 22, 2016)
===================================

- Add custom Collections template

# Quill 1.0.4-beta (February 3, 2016)
===================================

- Update transport package name to avoid conflict with another unrelated extra. This should also take care of an issue preventing Quill from showing up in the installer.

# Quill 1.0.3-beta (February 3, 2016)
===================================

- Improve mobile responsiveness
- Fix typo in Thoughts pagetitle [#1]
- UI improvements

# Quill 1.0.2-beta (January 25, 2016)
===================================

- Align pagination + newsletter form with content
- Fix hero image center alignment
- Remove hero image caption
- Further style tweaks

# Quill 1.0.1-beta (January 21, 2016)
===================================

- Fix Download URL
- Switch to pdoResources for archives and fix missing archives
- Add custom Collections view template to assets
- Center hero header on all screen sizes
- Increase stack order of float bars
- Add tether.min.js for Bootstrap tooltips
- Add Smooth Scrolling in page scripts
- Fix broken search icon on Safari

# Quill 1.0.0-beta (January 17, 2016)
===================================

- Initial release
