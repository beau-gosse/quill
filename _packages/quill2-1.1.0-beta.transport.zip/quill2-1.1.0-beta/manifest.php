<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Treigh PM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# Quill
Version: 1.1.0 Beta
![Introducing Quill](http://cdn.kleverr.com/pjx/quill/img/demo/quill-screenshot-10.jpg)

Quill is a sleek, modern and _clutter-free_ blog theme for [MODX](http://modx.com) that offers a more immersive reading experience. In just a few clicks, you\'ll have a fully functioning blog—thanks to MODX package dependencies.

## Demo
Quill is best previewed on the following pages:
1. [Live demo blog](http://quill.kleverr.modxcloud.com)
2. [Pattern Library](http://quill.kleverr.modxcloud.com/pattern-library/)
3. [Flight Manual](http://quill.kleverr.modxcloud.com/flight-manual/)

## Who is it for?
Quill is a One-Stop blogging solution for MODX that\'s designed to quickly get you in writing mode. By taking care of the heavy lifting, it allows you to focus on what matters most to you: Publishing your thoughts.

## Requirements

**MODX 2.4+** (Quill [installs](http://quill.kleverr.modxcloud.com/flight-manual/) required extras via package dependencies)

## Installation

1. [Download](http://modx.com/extras/package/quill) Quill via Package Management.
2. Click Install and follow the instructions.
3. Clear Cache.
4. Turn on Friendly URLs. (+ Rename the `ht.access` file to `.htaccess`)

## Upgrading
As of version **1.0.4 Beta**, Quill\'s transport package name has changed from `quill-x.x.x-release.transport.zip` to `quill2-x.x.x-release.transport.zip`. This helps avoid conflict with another unrelated extra. This should also take care of an issue preventing Quill from showing up in the installer. Before upgrading, you should back up your blog if upgrading from versions prior to **1.0.4 Beta**, as the upgrade  may duplicate data.

## Getting Started

- Visit Quill\'s official [documentation](http://quill.kleverr.modxcloud.com/flight-manual) to get started.
- Check out Quill\'s [Pattern Library](http://c0028.paas2.tx.modxcloud.com/introducing-quill/) for a complete style guide

## Included Extras

Quill installs the following extras to get things running:

- Collections
- Tagger
- pdoTools
- Archivist
- SimpleSearch
- ClientConfig
- If
- getUrlParam
- Rowboat
- Gravatar

## Main Features
![Image of a sample blog post themed by Quill](http://cdn.kleverr.com/pjx/quill/img/demo/quill-shot-9.png)

- Easily Customizable within the manager
- Pattern library for style references
- Clean, intuitive well-structured and well-commented markup
- Fully commented Sass source files
- Syntax highlighting (Prism.js)
- Built with Bootstrap V4 (alpha)
- Suggested posts
- Widgets: Newsletter signup form, Social share links, side notes, etc.
- Optional featured images
- SEO-optimized
- Cross-Browser Compatibility: Chrome, FF, Safari, Edge, Opera, IE9+
- 100% Responsive
- And more!

## Credits

Quill wouldn\'t be possible without these very useful assets:

- [JQuery](http://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js)
- [Bootstrap](http://v4-alpha.getbootstrap.com/)
- [Unveil.js](http://luis-almeida.github.io/unveil/)
- [Prism.js](http://prismjs.com/)
- Reading Time by [Michael Lynch](http://michaelynch.com/)
- [Disqus](http://c0028.paas2.tx.modxcloud.com/disqus.com)
- [SVG Icons](http://c0028.paas2.tx.modxcloud.com/svgicons.sparkk.fr)

Special thanks to MODX\'s John Peca (@theboxer) and Wayne Roddy (@dubROD) for the groundwork. Flatso theme and Git Package Management were invaluable when developing Quill. Shout-out to @donshakespeare for intensively testing out Quill\'s initial Beta release.
',
    'changelog' => 'Changelog file for Quill extra.

# Quill 1.1.0-beta (February 19, 2016)
===================================

- Add custom Collections template

# Quill 1.0.4-beta (February 3, 2016)
===================================

- Update transport package name to avoid conflict with another unrelated extra. This should also take care of an issue preventing Quill from showing up in the installer.

# Quill 1.0.3-beta (February 3, 2016)
===================================

- Improve mobile responsiveness
- Fix typo in Thoughts pagetitle [#1]
- UI improvements

# Quill 1.0.2-beta (January 25, 2016)
===================================

- Align pagination + newsletter form with content
- Fix hero image center alignment
- Remove hero image caption
- Further style tweaks

# Quill 1.0.1-beta (January 21, 2016)
===================================

- Fix Download URL
- Switch to pdoResources for archives and fix missing archives
- Add custom Collections view template to assets
- Center hero header on all screen sizes
- Increase stack order of float bars
- Add tether.min.js for Bootstrap tooltips
- Add Smooth Scrolling in page scripts
- Fix broken search icon on Safari

# Quill 1.0.0-beta (January 17, 2016)
===================================

- Initial release
',
    'setup-options' => 'quill2-1.1.0-beta/setup-options.php',
    'requires' => 
    array (
      'collections' => '>=3.2.0',
      'tagger' => '>=1.7.0',
      'pdotools' => '>=2.2.0',
      'archivist' => '>=1.2.0',
      'simplesearch' => '>=1.9.0',
      'if' => '>=1.1.0',
      'geturlparam' => '>=1.0',
      'clientconfig' => '>=1.3.0',
      'rowboat' => '>=1.1.0',
      'gravatar' => '>=2.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ccd0c84be63357179077e9ce33e744e4',
      'native_key' => 'quill2',
      'filename' => 'modNamespace/a0083ae96eca58ab51f41d40077319a9.vehicle',
      'namespace' => 'quill2',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f26751856a9f2f22aaa36a7005b8cbed',
      'native_key' => 'quill2.doc_container',
      'filename' => 'modSystemSetting/1c7dece3d21c96a08e31b33b92884192.vehicle',
      'namespace' => 'quill2',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '422553ad12eb1ad6e95cdfb828c825a0',
      'native_key' => 'quill2.blog_container',
      'filename' => 'modSystemSetting/2da7ae8087b53b0a07824a458188ecb0.vehicle',
      'namespace' => 'quill2',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf95d73cb9a4a3242c4a4384a6ef139d',
      'native_key' => 'quill2.sections_page',
      'filename' => 'modSystemSetting/3fe1b56906477c05de10dc6c67fb512b.vehicle',
      'namespace' => 'quill2',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bc291d9b28bd6bd2c959c6489f10355',
      'native_key' => 'quill2.topics_page',
      'filename' => 'modSystemSetting/5a3cdc314f01ce9fe1c6ac3216bd8911.vehicle',
      'namespace' => 'quill2',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bae9aba65c404d210b31cdeec691145e',
      'native_key' => 'quill2.authors_page',
      'filename' => 'modSystemSetting/cee503f90489d2e61eb1da0aafbff81b.vehicle',
      'namespace' => 'quill2',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2a0d19c6e65aecd0ebb0e2c309649ca',
      'native_key' => 'quill2.archives_page',
      'filename' => 'modSystemSetting/8d2ee841bdff0520c04ba7e49c9a8378.vehicle',
      'namespace' => 'quill2',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '573b7ad6a9e78aedf0573c775680289e',
      'native_key' => 'quill2.default_author_page',
      'filename' => 'modSystemSetting/f65d27dbc7d38286e6038ac27348757d.vehicle',
      'namespace' => 'quill2',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c26b290e11759586b6e7ef8f7dd10345',
      'native_key' => 'quill2.search_page',
      'filename' => 'modSystemSetting/a334b412e661410cd6804730a5505b7a.vehicle',
      'namespace' => 'quill2',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33a1fd5db931f44e553fe77250e45bd0',
      'native_key' => 'quill2.rss_page',
      'filename' => 'modSystemSetting/dee3d3613b5f86dfa4fcbd3a47b06fbd.vehicle',
      'namespace' => 'quill2',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0119c61f54ae12990d49cb949c4cd1b2',
      'native_key' => NULL,
      'filename' => 'modCategory/48208943244ab30e9cddb3e579b4ff58.vehicle',
      'namespace' => 'quill2',
    ),
  ),
);