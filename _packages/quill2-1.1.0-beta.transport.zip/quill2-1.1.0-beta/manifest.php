<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Treigh PM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# Quill
Version: 1.1.0 Beta
![Introducing Quill](http://cdn.kleverr.com/pjx/quill/img/demo/quill-screenshot-10.jpg)

Quill is a sleek, modern and _clutter-free_ blog theme for [MODX](http://modx.com) that offers a more immersive reading experience. In just a few clicks, you\'ll have a fully functioning blog—thanks to MODX package dependencies.

## Demo
Quill is best previewed on the following pages:
1. [Live demo blog](http://quill.kleverr.modxcloud.com)
2. [Pattern Library](http://quill.kleverr.modxcloud.com/pattern-library/)
3. [Flight Manual](http://quill.kleverr.modxcloud.com/flight-manual/)

## Who is it for?
Quill is a One-Stop blogging solution for MODX that\'s designed to quickly get you in writing mode. By taking care of the heavy lifting, it allows you to focus on what matters most to you: Publishing your thoughts.

## Requirements

**MODX 2.4+** (Quill [installs](http://quill.kleverr.modxcloud.com/flight-manual/) required extras via package dependencies)

## Installation

1. [Download](http://modx.com/extras/package/quill) Quill via Package Management.
2. Click Install and follow the instructions.
3. Clear Cache.
4. Turn on Friendly URLs. (+ Rename the `ht.access` file to `.htaccess`)

## Upgrading
As of version **1.0.4 Beta**, Quill\'s transport package name has changed from `quill-x.x.x-release.transport.zip` to `quill2-x.x.x-release.transport.zip`. This helps avoid conflict with another unrelated extra. This should also take care of an issue preventing Quill from showing up in the installer. Before upgrading, you should back up your blog if upgrading from versions prior to **1.0.4 Beta**, as the upgrade  may duplicate data.

## Getting Started

- Visit Quill\'s official [documentation](http://quill.kleverr.modxcloud.com/flight-manual) to get started.
- Check out Quill\'s [Pattern Library](http://c0028.paas2.tx.modxcloud.com/introducing-quill/) for a complete style guide

## Included Extras

Quill installs the following extras to get things running:

- Collections
- Tagger
- pdoTools
- Archivist
- SimpleSearch
- ClientConfig
- If
- getUrlParam
- Rowboat
- Gravatar

## Main Features
![Image of a sample blog post themed by Quill](http://cdn.kleverr.com/pjx/quill/img/demo/quill-shot-9.png)

- Easily Customizable within the manager
- Pattern library for style references
- Clean, intuitive well-structured and well-commented markup
- Fully commented Sass source files
- Syntax highlighting (Prism.js)
- Built with Bootstrap V4 (alpha)
- Suggested posts
- Widgets: Newsletter signup form, Social share links, side notes, etc.
- Optional featured images
- SEO-optimized
- Cross-Browser Compatibility: Chrome, FF, Safari, Edge, Opera, IE9+
- 100% Responsive
- And more!

## Credits

Quill wouldn\'t be possible without these very useful assets:

- [JQuery](http://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js)
- [Bootstrap](http://v4-alpha.getbootstrap.com/)
- [Unveil.js](http://luis-almeida.github.io/unveil/)
- [Prism.js](http://prismjs.com/)
- Reading Time by [Michael Lynch](http://michaelynch.com/)
- [Disqus](http://c0028.paas2.tx.modxcloud.com/disqus.com)
- [SVG Icons](http://c0028.paas2.tx.modxcloud.com/svgicons.sparkk.fr)

Special thanks to MODX\'s John Peca (@theboxer) and Wayne Roddy (@dubROD) for the groundwork. Flatso theme and Git Package Management were invaluable when developing Quill. Shout-out to @donshakespeare for intensively testing out Quill\'s initial Beta release.
',
    'changelog' => 'Changelog file for Quill extra.

# Quill 1.1.0-beta (February 23, 2016)
===================================

- Add custom Collections template
- Add French Lexicon strings
- Update blog container id system setting key
- Update search page id system setting key

# Quill 1.0.4-beta (February 3, 2016)
===================================

- Update transport package name to avoid conflict with another unrelated extra. This should also take care of an issue preventing Quill from showing up in the installer.

# Quill 1.0.3-beta (February 3, 2016)
===================================

- Improve mobile responsiveness
- Fix typo in Thoughts pagetitle [#1]
- UI improvements

# Quill 1.0.2-beta (January 25, 2016)
===================================

- Align pagination + newsletter form with content
- Fix hero image center alignment
- Remove hero image caption
- Further style tweaks

# Quill 1.0.1-beta (January 21, 2016)
===================================

- Fix Download URL
- Switch to pdoResources for archives and fix missing archives
- Add custom Collections view template to assets
- Center hero header on all screen sizes
- Increase stack order of float bars
- Add tether.min.js for Bootstrap tooltips
- Add Smooth Scrolling in page scripts
- Fix broken search icon on Safari

# Quill 1.0.0-beta (January 17, 2016)
===================================

- Initial release
',
    'setup-options' => 'quill2-1.1.0-beta/setup-options.php',
    'requires' => 
    array (
      'collections' => '>=3.2.0',
      'tagger' => '>=1.7.0',
      'pdotools' => '>=2.2.0',
      'archivist' => '>=1.2.0',
      'simplesearch' => '>=1.9.0',
      'if' => '>=1.1.0',
      'geturlparam' => '>=1.0',
      'clientconfig' => '>=1.3.0',
      'rowboat' => '>=1.1.0',
      'gravatar' => '>=2.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e85c3662a24ebee4f82106fc869ca18d',
      'native_key' => 'quill2',
      'filename' => 'modNamespace/568612887f136746ae888e0c4b594963.vehicle',
      'namespace' => 'quill2',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82c9af735916962033c1c556ec6968bc',
      'native_key' => 'quill2.doc_container',
      'filename' => 'modSystemSetting/8c5d9a57229998c4b52dbc21437aafa9.vehicle',
      'namespace' => 'quill2',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76d4c9120e1a9c4465f7686b47d16e2c',
      'native_key' => 'quill2.blog_container',
      'filename' => 'modSystemSetting/ce6674cd70d3ae88418e69c8f3435df0.vehicle',
      'namespace' => 'quill2',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f89954ed4fd323e7c875832121f90be0',
      'native_key' => 'quill2.sections_page',
      'filename' => 'modSystemSetting/56a484ad03cf47a94aa42c8895a11940.vehicle',
      'namespace' => 'quill2',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05585bd0aa59bf1def142c8a98489b2e',
      'native_key' => 'quill2.topics_page',
      'filename' => 'modSystemSetting/551318ed54e17270fbcb0715169a3950.vehicle',
      'namespace' => 'quill2',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7693b9abc662ec913c57b9f60c11a827',
      'native_key' => 'quill2.authors_page',
      'filename' => 'modSystemSetting/3fd89eb8e7430fb62145b7016ccf1220.vehicle',
      'namespace' => 'quill2',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c0e3d0304e9ee7207725a52203de137',
      'native_key' => 'quill2.archives_page',
      'filename' => 'modSystemSetting/8aed6c7c8147ccfe9e44014e0cd6f9df.vehicle',
      'namespace' => 'quill2',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '249cadca33c463dcc793c2407dcb13e6',
      'native_key' => 'quill2.default_author_page',
      'filename' => 'modSystemSetting/c271f5909974dad4684bc5bb0f7625a5.vehicle',
      'namespace' => 'quill2',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f48db40ade278e8c94114a61560d46c',
      'native_key' => 'quill2.search_page',
      'filename' => 'modSystemSetting/38f1c726f207efaa8d1e6b6098dd6b3d.vehicle',
      'namespace' => 'quill2',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2404479c8738f238e8d5826fd05e24a',
      'native_key' => 'quill2.rss_page',
      'filename' => 'modSystemSetting/52156811e9e4d65be978a17b14640181.vehicle',
      'namespace' => 'quill2',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b925be22d3a0d3f2440f5b9a2ebd9c93',
      'native_key' => NULL,
      'filename' => 'modCategory/a7ba26fceda3f33cbf35e6edb96a296b.vehicle',
      'namespace' => 'quill2',
    ),
  ),
);