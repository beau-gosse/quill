<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Treigh PM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# Quill
Version: 1.1.0 Beta
![Introducing Quill](http://cdn.kleverr.com/pjx/quill/img/demo/quill-screenshot-10.jpg)

Quill is a sleek, modern and _clutter-free_ blog theme for [MODX](http://modx.com) that offers a more immersive reading experience. In just a few clicks, you\'ll have a fully functioning blog—thanks to MODX package dependencies.

## Demo
Quill is best previewed on the following pages:
1. [Live demo blog](http://quill.kleverr.modxcloud.com)
2. [Pattern Library](http://quill.kleverr.modxcloud.com/pattern-library/)
3. [Flight Manual](http://quill.kleverr.modxcloud.com/flight-manual/)

## Who is it for?
Quill is a One-Stop blogging solution for MODX that\'s designed to quickly get you in writing mode. By taking care of the heavy lifting, it allows you to focus on what matters most to you: Publishing your thoughts.

## Requirements

**MODX 2.4+** (Quill [installs](http://quill.kleverr.modxcloud.com/flight-manual/) required extras via package dependencies)

## Installation

1. [Download](http://modx.com/extras/package/quill) Quill via Package Management.
2. Click Install and follow the instructions.
3. Clear Cache.
4. Turn on Friendly URLs. (+ Rename the `ht.access` file to `.htaccess`)

## Upgrading
As of version **1.0.4 Beta**, Quill\'s transport package name has changed from `quill-x.x.x-release.transport.zip` to `quill2-x.x.x-release.transport.zip`. This helps avoid conflict with another unrelated extra. This should also take care of an issue preventing Quill from showing up in the installer. Before upgrading, you should back up your blog if upgrading from versions prior to **1.0.4 Beta**, as the upgrade  may duplicate data.

## Getting Started

- Visit Quill\'s official [documentation](http://quill.kleverr.modxcloud.com/flight-manual) to get started.
- Check out Quill\'s [Pattern Library](http://c0028.paas2.tx.modxcloud.com/introducing-quill/) for a complete style guide

## Included Extras

Quill installs the following extras to get things running:

- Collections
- Tagger
- pdoTools
- Archivist
- SimpleSearch
- ClientConfig
- If
- getUrlParam
- Rowboat
- Gravatar

## Main Features
![Image of a sample blog post themed by Quill](http://cdn.kleverr.com/pjx/quill/img/demo/quill-shot-9.png)

- Easily Customizable within the manager
- Pattern library for style references
- Clean, intuitive well-structured and well-commented markup
- Fully commented Sass source files
- Syntax highlighting (Prism.js)
- Built with Bootstrap V4 (alpha)
- Suggested posts
- Widgets: Newsletter signup form, Social share links, side notes, etc.
- Optional featured images
- SEO-optimized
- Cross-Browser Compatibility: Chrome, FF, Safari, Edge, Opera, IE9+
- 100% Responsive
- And more!

## Credits

Quill wouldn\'t be possible without these very useful assets:

- [JQuery](http://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js)
- [Bootstrap](http://v4-alpha.getbootstrap.com/)
- [Unveil.js](http://luis-almeida.github.io/unveil/)
- [Prism.js](http://prismjs.com/)
- Reading Time by [Michael Lynch](http://michaelynch.com/)
- [Disqus](http://c0028.paas2.tx.modxcloud.com/disqus.com)
- [SVG Icons](http://c0028.paas2.tx.modxcloud.com/svgicons.sparkk.fr)

Special thanks to MODX\'s John Peca (@theboxer) and Wayne Roddy (@dubROD) for the groundwork. Flatso theme and Git Package Management were invaluable when developing Quill. Shout-out to @donshakespeare for intensively testing out Quill\'s initial Beta release.
',
    'changelog' => 'Changelog file for Quill extra.

# Quill 1.1.0-beta (February 19, 2016)
===================================

- Add custom Collections template

# Quill 1.0.4-beta (February 3, 2016)
===================================

- Update transport package name to avoid conflict with another unrelated extra. This should also take care of an issue preventing Quill from showing up in the installer.

# Quill 1.0.3-beta (February 3, 2016)
===================================

- Improve mobile responsiveness
- Fix typo in Thoughts pagetitle [#1]
- UI improvements

# Quill 1.0.2-beta (January 25, 2016)
===================================

- Align pagination + newsletter form with content
- Fix hero image center alignment
- Remove hero image caption
- Further style tweaks

# Quill 1.0.1-beta (January 21, 2016)
===================================

- Fix Download URL
- Switch to pdoResources for archives and fix missing archives
- Add custom Collections view template to assets
- Center hero header on all screen sizes
- Increase stack order of float bars
- Add tether.min.js for Bootstrap tooltips
- Add Smooth Scrolling in page scripts
- Fix broken search icon on Safari

# Quill 1.0.0-beta (January 17, 2016)
===================================

- Initial release
',
    'setup-options' => 'quill2-1.1.0-beta/setup-options.php',
    'requires' => 
    array (
      'collections' => '>=3.2.0',
      'tagger' => '>=1.7.0',
      'pdotools' => '>=2.2.0',
      'archivist' => '>=1.2.0',
      'simplesearch' => '>=1.9.0',
      'if' => '>=1.1.0',
      'geturlparam' => '>=1.0',
      'clientconfig' => '>=1.3.0',
      'rowboat' => '>=1.1.0',
      'gravatar' => '>=2.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f2a758610bf0a8e4cdde24d78cc4c19c',
      'native_key' => 'quill2',
      'filename' => 'modNamespace/f72ee13f218e76c390651f219f84d7c4.vehicle',
      'namespace' => 'quill2',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd82283eb20d4dadcaed9146d72dbb254',
      'native_key' => 'quill2.doc_container',
      'filename' => 'modSystemSetting/730935d0a75f1a793d4837edd191cf03.vehicle',
      'namespace' => 'quill2',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65d1df1928143146dcae3f0eae4a36d5',
      'native_key' => 'quill2.blog_container',
      'filename' => 'modSystemSetting/e07cfd35cda59aeef2fa6801e0015071.vehicle',
      'namespace' => 'quill2',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c8563738dd02be1df2f4fc6b97e2882',
      'native_key' => 'quill2.sections_page',
      'filename' => 'modSystemSetting/c12cde3c576cb7c913d52d3186bbaacd.vehicle',
      'namespace' => 'quill2',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca08254b1306c034a910a985e8143f9d',
      'native_key' => 'quill2.topics_page',
      'filename' => 'modSystemSetting/2ce6da8a313b85a19ccfbf573cd020fc.vehicle',
      'namespace' => 'quill2',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '913e3a60682dd73166ab1024f62c54a7',
      'native_key' => 'quill2.authors_page',
      'filename' => 'modSystemSetting/0909732dde96558321222f37d54b31c7.vehicle',
      'namespace' => 'quill2',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b398473e6ac6c66ed0ecd1a7b4818d7b',
      'native_key' => 'quill2.archives_page',
      'filename' => 'modSystemSetting/3cfe17280a7ab0e88bef92fa25fee6b3.vehicle',
      'namespace' => 'quill2',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8f72bf444f4842b1822d6f97d4209af',
      'native_key' => 'quill2.default_author_page',
      'filename' => 'modSystemSetting/fd4e297278466f15d1da715e46dd7fed.vehicle',
      'namespace' => 'quill2',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e54b0f1dc084f56828a87f95013d838a',
      'native_key' => 'quill2.search_page',
      'filename' => 'modSystemSetting/eaf204835908586d21eecc8390340441.vehicle',
      'namespace' => 'quill2',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a426b518ed2a4335e236fb4bf6a6297',
      'native_key' => 'quill2.rss_page',
      'filename' => 'modSystemSetting/f351fc2e15ed0e393419479bee647892.vehicle',
      'namespace' => 'quill2',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a1d47c7357ac0adf9dc75ab9cf88c1b1',
      'native_key' => NULL,
      'filename' => 'modCategory/43e96582b00de78fa3dbb1d2dbfab7b6.vehicle',
      'namespace' => 'quill2',
    ),
  ),
);